﻿using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

using Microsoft.Extensions.Logging;
using SalasEveris.Controllers;
using Xunit;

namespace SalasEveris.IntegrationTests
{
    public class RoomAllocatorControllerTests : IntegrationTest
    {
        private readonly ILogger<RoomAllocatorController> _logger;
        private readonly RoomContext _context;

        [Fact]
        public async Task GetAll_WithoutAnyRoom_ReturnsEmptyResponse()
        {
            //Arrange            

            //Act
            var contr = new RoomAllocatorController(_logger, _context);

            var response = await TestClient.GetAsync("https://localhost:7001/api/rooms");
            
            //Assert
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            (await response.Content.ReadAsAsync<List<Room>>()).Should().BeEmpty();
        }
        [Fact]
        public async Task Get_ReturnPost_WhenPostExistsInTheDatabase()
        {
            //Arrange
            var createdRoom = await RoomAllocatorController.Post(new Room {Name="Sala Prueba" });

            //Act
            var response = await TestClient.PostAsync("https://localhost:7001/api/rooms");

            //Assert
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var createdRoom = await response.Content.ReadAsAsync<Room>();
            createdRoom.Id.Should().Be(createdRoom.Id);
            returnedRoom.Name.Should().Be("Sala Prueba");

        }
        
    }
}
